window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "Obscure 2.1.1",
   "version": "2.1.1",
   "homepage": "https://www.google.com/",
   "enableNavBttns": true,
   "enableHomeBttn": true,
   "enableLogoutBttn": false,
   "termsOfService": "",
   "kioskEnabled": false
};